-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
-- Tool Version Limit: 2023.05
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity lockin_top_ctl_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 16;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    ctl                   :out  STD_LOGIC_VECTOR(31 downto 0);
    kfix                  :out  STD_LOGIC_VECTOR(4 downto 0);
    ph_ref                :out  STD_LOGIC_VECTOR(31 downto 0);
    ph_sig                :out  STD_LOGIC_VECTOR(31 downto 0);
    ph_off                :out  STD_LOGIC_VECTOR(31 downto 0);
    amp                   :out  STD_LOGIC_VECTOR(15 downto 0);
    sigma                 :out  STD_LOGIC_VECTOR(15 downto 0);
    seed                  :out  STD_LOGIC_VECTOR(31 downto 0);
    log_every             :out  STD_LOGIC_VECTOR(15 downto 0);
    x_ext                 :out  STD_LOGIC_VECTOR(15 downto 0);
    out_count             :in   STD_LOGIC_VECTOR(31 downto 0);
    out_count_ap_vld      :in   STD_LOGIC;
    log_n                 :in   STD_LOGIC_VECTOR(31 downto 0);
    log_n_ap_vld          :in   STD_LOGIC;
    status                :in   STD_LOGIC_VECTOR(31 downto 0);
    status_ap_vld         :in   STD_LOGIC;
    k_now                 :in   STD_LOGIC_VECTOR(4 downto 0);
    k_now_ap_vld          :in   STD_LOGIC;
    mI_now                :in   STD_LOGIC_VECTOR(31 downto 0);
    mI_now_ap_vld         :in   STD_LOGIC;
    mQ_now                :in   STD_LOGIC_VECTOR(31 downto 0);
    mQ_now_ap_vld         :in   STD_LOGIC;
    mag_now               :in   STD_LOGIC_VECTOR(15 downto 0);
    mag_now_ap_vld        :in   STD_LOGIC;
    log_mem_address0      :in   STD_LOGIC_VECTOR(12 downto 0);
    log_mem_ce0           :in   STD_LOGIC;
    log_mem_we0           :in   STD_LOGIC;
    log_mem_d0            :in   STD_LOGIC_VECTOR(31 downto 0);
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC
);
end entity lockin_top_ctl_s_axi;

-- ------------------------Address Info-------------------
-- 0x0000 : Control signals
--          bit 0  - ap_start (Read/Write/COH)
--          bit 1  - ap_done (Read/COR)
--          bit 2  - ap_idle (Read)
--          bit 3  - ap_ready (Read/COR)
--          bit 7  - auto_restart (Read/Write)
--          bit 9  - interrupt (Read)
--          others - reserved
-- 0x0004 : Global Interrupt Enable Register
--          bit 0  - Global Interrupt Enable (Read/Write)
--          others - reserved
-- 0x0008 : IP Interrupt Enable Register (Read/Write)
--          bit 0 - enable ap_done interrupt (Read/Write)
--          bit 1 - enable ap_ready interrupt (Read/Write)
--          others - reserved
-- 0x000c : IP Interrupt Status Register (Read/TOW)
--          bit 0 - ap_done (Read/TOW)
--          bit 1 - ap_ready (Read/TOW)
--          others - reserved
-- 0x0010 : Data signal of ctl
--          bit 31~0 - ctl[31:0] (Read/Write)
-- 0x0014 : reserved
-- 0x0018 : Data signal of kfix
--          bit 4~0 - kfix[4:0] (Read/Write)
--          others  - reserved
-- 0x001c : reserved
-- 0x0020 : Data signal of ph_ref
--          bit 31~0 - ph_ref[31:0] (Read/Write)
-- 0x0024 : reserved
-- 0x0028 : Data signal of ph_sig
--          bit 31~0 - ph_sig[31:0] (Read/Write)
-- 0x002c : reserved
-- 0x0030 : Data signal of ph_off
--          bit 31~0 - ph_off[31:0] (Read/Write)
-- 0x0034 : reserved
-- 0x0038 : Data signal of amp
--          bit 15~0 - amp[15:0] (Read/Write)
--          others   - reserved
-- 0x003c : reserved
-- 0x0040 : Data signal of sigma
--          bit 15~0 - sigma[15:0] (Read/Write)
--          others   - reserved
-- 0x0044 : reserved
-- 0x0048 : Data signal of seed
--          bit 31~0 - seed[31:0] (Read/Write)
-- 0x004c : reserved
-- 0x0050 : Data signal of log_every
--          bit 15~0 - log_every[15:0] (Read/Write)
--          others   - reserved
-- 0x0054 : reserved
-- 0x0058 : Data signal of x_ext
--          bit 15~0 - x_ext[15:0] (Read/Write)
--          others   - reserved
-- 0x005c : reserved
-- 0x0060 : Data signal of out_count
--          bit 31~0 - out_count[31:0] (Read)
-- 0x0064 : Control signal of out_count
--          bit 0  - out_count_ap_vld (Read/COR)
--          others - reserved
-- 0x0070 : Data signal of log_n
--          bit 31~0 - log_n[31:0] (Read)
-- 0x0074 : Control signal of log_n
--          bit 0  - log_n_ap_vld (Read/COR)
--          others - reserved
-- 0x0080 : Data signal of status
--          bit 31~0 - status[31:0] (Read)
-- 0x0084 : Control signal of status
--          bit 0  - status_ap_vld (Read/COR)
--          others - reserved
-- 0x0090 : Data signal of k_now
--          bit 4~0 - k_now[4:0] (Read)
--          others  - reserved
-- 0x0094 : Control signal of k_now
--          bit 0  - k_now_ap_vld (Read/COR)
--          others - reserved
-- 0x00a0 : Data signal of mI_now
--          bit 31~0 - mI_now[31:0] (Read)
-- 0x00a4 : Control signal of mI_now
--          bit 0  - mI_now_ap_vld (Read/COR)
--          others - reserved
-- 0x00b0 : Data signal of mQ_now
--          bit 31~0 - mQ_now[31:0] (Read)
-- 0x00b4 : Control signal of mQ_now
--          bit 0  - mQ_now_ap_vld (Read/COR)
--          others - reserved
-- 0x00c0 : Data signal of mag_now
--          bit 15~0 - mag_now[15:0] (Read)
--          others   - reserved
-- 0x00c4 : Control signal of mag_now
--          bit 0  - mag_now_ap_vld (Read/COR)
--          others - reserved
-- 0x8000 ~
-- 0xffff : Memory 'log_mem' (8192 * 32b)
--          Word n : bit [31:0] - log_mem[n]
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of lockin_top_ctl_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL          : INTEGER := 16#0000#;
    constant ADDR_GIE              : INTEGER := 16#0004#;
    constant ADDR_IER              : INTEGER := 16#0008#;
    constant ADDR_ISR              : INTEGER := 16#000c#;
    constant ADDR_CTL_DATA_0       : INTEGER := 16#0010#;
    constant ADDR_CTL_CTRL         : INTEGER := 16#0014#;
    constant ADDR_KFIX_DATA_0      : INTEGER := 16#0018#;
    constant ADDR_KFIX_CTRL        : INTEGER := 16#001c#;
    constant ADDR_PH_REF_DATA_0    : INTEGER := 16#0020#;
    constant ADDR_PH_REF_CTRL      : INTEGER := 16#0024#;
    constant ADDR_PH_SIG_DATA_0    : INTEGER := 16#0028#;
    constant ADDR_PH_SIG_CTRL      : INTEGER := 16#002c#;
    constant ADDR_PH_OFF_DATA_0    : INTEGER := 16#0030#;
    constant ADDR_PH_OFF_CTRL      : INTEGER := 16#0034#;
    constant ADDR_AMP_DATA_0       : INTEGER := 16#0038#;
    constant ADDR_AMP_CTRL         : INTEGER := 16#003c#;
    constant ADDR_SIGMA_DATA_0     : INTEGER := 16#0040#;
    constant ADDR_SIGMA_CTRL       : INTEGER := 16#0044#;
    constant ADDR_SEED_DATA_0      : INTEGER := 16#0048#;
    constant ADDR_SEED_CTRL        : INTEGER := 16#004c#;
    constant ADDR_LOG_EVERY_DATA_0 : INTEGER := 16#0050#;
    constant ADDR_LOG_EVERY_CTRL   : INTEGER := 16#0054#;
    constant ADDR_X_EXT_DATA_0     : INTEGER := 16#0058#;
    constant ADDR_X_EXT_CTRL       : INTEGER := 16#005c#;
    constant ADDR_OUT_COUNT_DATA_0 : INTEGER := 16#0060#;
    constant ADDR_OUT_COUNT_CTRL   : INTEGER := 16#0064#;
    constant ADDR_LOG_N_DATA_0     : INTEGER := 16#0070#;
    constant ADDR_LOG_N_CTRL       : INTEGER := 16#0074#;
    constant ADDR_STATUS_DATA_0    : INTEGER := 16#0080#;
    constant ADDR_STATUS_CTRL      : INTEGER := 16#0084#;
    constant ADDR_K_NOW_DATA_0     : INTEGER := 16#0090#;
    constant ADDR_K_NOW_CTRL       : INTEGER := 16#0094#;
    constant ADDR_MI_NOW_DATA_0    : INTEGER := 16#00a0#;
    constant ADDR_MI_NOW_CTRL      : INTEGER := 16#00a4#;
    constant ADDR_MQ_NOW_DATA_0    : INTEGER := 16#00b0#;
    constant ADDR_MQ_NOW_CTRL      : INTEGER := 16#00b4#;
    constant ADDR_MAG_NOW_DATA_0   : INTEGER := 16#00c0#;
    constant ADDR_MAG_NOW_CTRL     : INTEGER := 16#00c4#;
    constant ADDR_LOG_MEM_BASE     : INTEGER := 16#8000#;
    constant ADDR_LOG_MEM_HIGH     : INTEGER := 16#ffff#;
    constant ADDR_BITS         : INTEGER := 16;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_ctl             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_kfix            : UNSIGNED(4 downto 0) := (others => '0');
    signal int_ph_ref          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ph_sig          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ph_off          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_amp             : UNSIGNED(15 downto 0) := (others => '0');
    signal int_sigma           : UNSIGNED(15 downto 0) := (others => '0');
    signal int_seed            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_log_every       : UNSIGNED(15 downto 0) := (others => '0');
    signal int_x_ext           : UNSIGNED(15 downto 0) := (others => '0');
    signal int_out_count_ap_vld : STD_LOGIC;
    signal int_out_count       : UNSIGNED(31 downto 0) := (others => '0');
    signal int_log_n_ap_vld    : STD_LOGIC;
    signal int_log_n           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_status_ap_vld   : STD_LOGIC;
    signal int_status          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_k_now_ap_vld    : STD_LOGIC;
    signal int_k_now           : UNSIGNED(4 downto 0) := (others => '0');
    signal int_mI_now_ap_vld   : STD_LOGIC;
    signal int_mI_now          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_mQ_now_ap_vld   : STD_LOGIC;
    signal int_mQ_now          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_mag_now_ap_vld  : STD_LOGIC;
    signal int_mag_now         : UNSIGNED(15 downto 0) := (others => '0');
    -- memory signals
    signal int_log_mem_address0 : UNSIGNED(12 downto 0);
    signal int_log_mem_ce0     : STD_LOGIC;
    signal int_log_mem_be0     : UNSIGNED(3 downto 0);
    signal int_log_mem_d0      : UNSIGNED(31 downto 0);
    signal int_log_mem_address1 : UNSIGNED(12 downto 0);
    signal int_log_mem_ce1     : STD_LOGIC;
    signal int_log_mem_q1      : UNSIGNED(31 downto 0);
    signal int_log_mem_read    : STD_LOGIC;
    signal int_log_mem_write   : STD_LOGIC;

    component lockin_top_ctl_s_axi_ram is
        generic (
            MEM_STYLE : STRING :="auto";
            MEM_TYPE  : STRING :="S2P";
            BYTES   : INTEGER :=4;
            DEPTH   : INTEGER :=256;
            AWIDTH  : INTEGER :=8);
        port (
            clk0    : in  STD_LOGIC;
            address0: in  UNSIGNED(AWIDTH-1 downto 0);
            ce0     : in  STD_LOGIC;
            we0     : in  UNSIGNED(BYTES-1 downto 0);
            d0      : in  UNSIGNED(BYTES*8-1 downto 0);
            q0      : out UNSIGNED(BYTES*8-1 downto 0);
            clk1    : in  STD_LOGIC;
            address1: in  UNSIGNED(AWIDTH-1 downto 0);
            ce1     : in  STD_LOGIC;
            we1     : in  UNSIGNED(BYTES-1 downto 0);
            d1      : in  UNSIGNED(BYTES*8-1 downto 0);
            q1      : out UNSIGNED(BYTES*8-1 downto 0));
    end component lockin_top_ctl_s_axi_ram;

    function log2 (x : INTEGER) return INTEGER is
        variable n, m : INTEGER;
    begin
        n := 1;
        m := 2;
        while m < x loop
            n := n + 1;
            m := m * 2;
        end loop;
        return n;
    end function log2;

begin
-- ----------------------- Instantiation------------------
-- int_log_mem
int_log_mem : lockin_top_ctl_s_axi_ram
generic map (
     MEM_STYLE => "auto",
     MEM_TYPE  => "S2P",
     BYTES     => 4,
     DEPTH     => 8192,
     AWIDTH    => log2(8192))
port map (
     clk0      => ACLK,
     address0  => int_log_mem_address0,
     ce0       => int_log_mem_ce0,
     we0       => int_log_mem_be0,
     d0        => int_log_mem_d0,
     q0        => open,
     clk1      => ACLK,
     address1  => int_log_mem_address1,
     ce1       => int_log_mem_ce1,
     we1       => (others=>'0'),
     d1        => (others=>'0'),
     q1        => int_log_mem_q1);


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata and ar_hs = '0' else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, w_hs, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (w_hs = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 0));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) and (int_log_mem_read = '0') else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_CTL_DATA_0 =>
                        rdata_data <= RESIZE(int_ctl(31 downto 0), 32);
                    when ADDR_KFIX_DATA_0 =>
                        rdata_data <= RESIZE(int_kfix(4 downto 0), 32);
                    when ADDR_PH_REF_DATA_0 =>
                        rdata_data <= RESIZE(int_ph_ref(31 downto 0), 32);
                    when ADDR_PH_SIG_DATA_0 =>
                        rdata_data <= RESIZE(int_ph_sig(31 downto 0), 32);
                    when ADDR_PH_OFF_DATA_0 =>
                        rdata_data <= RESIZE(int_ph_off(31 downto 0), 32);
                    when ADDR_AMP_DATA_0 =>
                        rdata_data <= RESIZE(int_amp(15 downto 0), 32);
                    when ADDR_SIGMA_DATA_0 =>
                        rdata_data <= RESIZE(int_sigma(15 downto 0), 32);
                    when ADDR_SEED_DATA_0 =>
                        rdata_data <= RESIZE(int_seed(31 downto 0), 32);
                    when ADDR_LOG_EVERY_DATA_0 =>
                        rdata_data <= RESIZE(int_log_every(15 downto 0), 32);
                    when ADDR_X_EXT_DATA_0 =>
                        rdata_data <= RESIZE(int_x_ext(15 downto 0), 32);
                    when ADDR_OUT_COUNT_DATA_0 =>
                        rdata_data <= RESIZE(int_out_count(31 downto 0), 32);
                    when ADDR_OUT_COUNT_CTRL =>
                        rdata_data(0) <= int_out_count_ap_vld;
                    when ADDR_LOG_N_DATA_0 =>
                        rdata_data <= RESIZE(int_log_n(31 downto 0), 32);
                    when ADDR_LOG_N_CTRL =>
                        rdata_data(0) <= int_log_n_ap_vld;
                    when ADDR_STATUS_DATA_0 =>
                        rdata_data <= RESIZE(int_status(31 downto 0), 32);
                    when ADDR_STATUS_CTRL =>
                        rdata_data(0) <= int_status_ap_vld;
                    when ADDR_K_NOW_DATA_0 =>
                        rdata_data <= RESIZE(int_k_now(4 downto 0), 32);
                    when ADDR_K_NOW_CTRL =>
                        rdata_data(0) <= int_k_now_ap_vld;
                    when ADDR_MI_NOW_DATA_0 =>
                        rdata_data <= RESIZE(int_mI_now(31 downto 0), 32);
                    when ADDR_MI_NOW_CTRL =>
                        rdata_data(0) <= int_mI_now_ap_vld;
                    when ADDR_MQ_NOW_DATA_0 =>
                        rdata_data <= RESIZE(int_mQ_now(31 downto 0), 32);
                    when ADDR_MQ_NOW_CTRL =>
                        rdata_data(0) <= int_mQ_now_ap_vld;
                    when ADDR_MAG_NOW_DATA_0 =>
                        rdata_data <= RESIZE(int_mag_now(15 downto 0), 32);
                    when ADDR_MAG_NOW_CTRL =>
                        rdata_data(0) <= int_mag_now_ap_vld;
                    when others =>
                        NULL;
                    end case;
                elsif (int_log_mem_read = '1') then
                    rdata_data <= int_log_mem_q1;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    ctl                  <= STD_LOGIC_VECTOR(int_ctl);
    kfix                 <= STD_LOGIC_VECTOR(int_kfix);
    ph_ref               <= STD_LOGIC_VECTOR(int_ph_ref);
    ph_sig               <= STD_LOGIC_VECTOR(int_ph_sig);
    ph_off               <= STD_LOGIC_VECTOR(int_ph_off);
    amp                  <= STD_LOGIC_VECTOR(int_amp);
    sigma                <= STD_LOGIC_VECTOR(int_sigma);
    seed                 <= STD_LOGIC_VECTOR(int_seed);
    log_every            <= STD_LOGIC_VECTOR(int_log_every);
    x_ext                <= STD_LOGIC_VECTOR(int_x_ext);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_CTL_DATA_0) then
                    int_ctl(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ctl(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_KFIX_DATA_0) then
                    int_kfix(4 downto 0) <= (UNSIGNED(WDATA(4 downto 0)) and wmask(4 downto 0)) or ((not wmask(4 downto 0)) and int_kfix(4 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PH_REF_DATA_0) then
                    int_ph_ref(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ph_ref(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PH_SIG_DATA_0) then
                    int_ph_sig(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ph_sig(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PH_OFF_DATA_0) then
                    int_ph_off(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ph_off(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AMP_DATA_0) then
                    int_amp(15 downto 0) <= (UNSIGNED(WDATA(15 downto 0)) and wmask(15 downto 0)) or ((not wmask(15 downto 0)) and int_amp(15 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SIGMA_DATA_0) then
                    int_sigma(15 downto 0) <= (UNSIGNED(WDATA(15 downto 0)) and wmask(15 downto 0)) or ((not wmask(15 downto 0)) and int_sigma(15 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEED_DATA_0) then
                    int_seed(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_seed(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LOG_EVERY_DATA_0) then
                    int_log_every(15 downto 0) <= (UNSIGNED(WDATA(15 downto 0)) and wmask(15 downto 0)) or ((not wmask(15 downto 0)) and int_log_every(15 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_EXT_DATA_0) then
                    int_x_ext(15 downto 0) <= (UNSIGNED(WDATA(15 downto 0)) and wmask(15 downto 0)) or ((not wmask(15 downto 0)) and int_x_ext(15 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_out_count <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (out_count_ap_vld = '1') then
                    int_out_count <= UNSIGNED(out_count);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_out_count_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (out_count_ap_vld = '1') then
                    int_out_count_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_OUT_COUNT_CTRL) then
                    int_out_count_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_log_n <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (log_n_ap_vld = '1') then
                    int_log_n <= UNSIGNED(log_n);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_log_n_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (log_n_ap_vld = '1') then
                    int_log_n_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_LOG_N_CTRL) then
                    int_log_n_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_status <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (status_ap_vld = '1') then
                    int_status <= UNSIGNED(status);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_status_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (status_ap_vld = '1') then
                    int_status_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_STATUS_CTRL) then
                    int_status_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_k_now <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (k_now_ap_vld = '1') then
                    int_k_now <= UNSIGNED(k_now);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_k_now_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (k_now_ap_vld = '1') then
                    int_k_now_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_K_NOW_CTRL) then
                    int_k_now_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mI_now <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (mI_now_ap_vld = '1') then
                    int_mI_now <= UNSIGNED(mI_now);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mI_now_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (mI_now_ap_vld = '1') then
                    int_mI_now_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_MI_NOW_CTRL) then
                    int_mI_now_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mQ_now <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (mQ_now_ap_vld = '1') then
                    int_mQ_now <= UNSIGNED(mQ_now);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mQ_now_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (mQ_now_ap_vld = '1') then
                    int_mQ_now_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_MQ_NOW_CTRL) then
                    int_mQ_now_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mag_now <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (mag_now_ap_vld = '1') then
                    int_mag_now <= UNSIGNED(mag_now);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mag_now_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (mag_now_ap_vld = '1') then
                    int_mag_now_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_MAG_NOW_CTRL) then
                    int_mag_now_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------
    -- log_mem
    int_log_mem_address0 <= UNSIGNED(log_mem_address0);
    int_log_mem_ce0      <= log_mem_ce0;
    int_log_mem_be0      <= (others => log_mem_we0);
    int_log_mem_d0       <= RESIZE(UNSIGNED(log_mem_d0), 32);
    int_log_mem_address1 <= raddr(14 downto 2) when ar_hs = '1' else waddr(14 downto 2);
    int_log_mem_ce1      <= '1' when ar_hs = '1' or (int_log_mem_write = '1' and WVALID  = '1') else '0';

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_log_mem_read <= '0';
            elsif (ACLK_EN = '1') then
                if (ar_hs = '1' and raddr >= ADDR_LOG_MEM_BASE and raddr <= ADDR_LOG_MEM_HIGH) then
                    int_log_mem_read <= '1';
                else
                    int_log_mem_read <= '0';
                end if;
            end if;
        end if;
    end process;


end architecture behave;

library IEEE;
USE IEEE.std_logic_1164.all;
USE IEEE.numeric_std.all;

entity lockin_top_ctl_s_axi_ram is
    generic (
        MEM_STYLE : STRING :="auto";
        MEM_TYPE  : STRING :="S2P";
        BYTES   : INTEGER :=4;
        DEPTH   : INTEGER :=256;
        AWIDTH  : INTEGER :=8);
    port (
        clk0    : in  STD_LOGIC;
        address0: in  UNSIGNED(AWIDTH-1 downto 0);
        ce0     : in  STD_LOGIC;
        we0     : in  UNSIGNED(BYTES-1 downto 0);
        d0      : in  UNSIGNED(BYTES*8-1 downto 0);
        q0      : out UNSIGNED(BYTES*8-1 downto 0);
        clk1    : in  STD_LOGIC;
        address1: in  UNSIGNED(AWIDTH-1 downto 0);
        ce1     : in  STD_LOGIC;
        we1     : in  UNSIGNED(BYTES-1 downto 0);
        d1      : in  UNSIGNED(BYTES*8-1 downto 0);
        q1      : out UNSIGNED(BYTES*8-1 downto 0));

end entity lockin_top_ctl_s_axi_ram;

architecture behave of lockin_top_ctl_s_axi_ram is
    signal address0_tmp : UNSIGNED(AWIDTH-1 downto 0);
    signal address1_tmp : UNSIGNED(AWIDTH-1 downto 0);
    type RAM_T is array (0 to DEPTH - 1) of UNSIGNED(BYTES*8 - 1 downto 0);
    shared variable mem : RAM_T := (others => (others => '0'));
    attribute ram_style: string;
    attribute ram_style of mem: variable is MEM_STYLE;
    constant BYTE_WIDTH :INTEGER := 8;

    function port_type_gen( MEM_TYPE: STRING; MEM_STYLE: STRING; PORT_NAME: STRING) return STRING is
    begin
        if (MEM_TYPE = "S2P") and (PORT_NAME = "PORT0") then
            return "WO";
        elsif((MEM_TYPE = "S2P") and (PORT_NAME = "PORT1")) or ((MEM_TYPE = "2P") and (PORT_NAME = "PORT0")) then
            return "RO";
        elsif (MEM_STYLE = "hls_ultra") then
            return "RWNC";
        else
            return "RWRF";
        end if;
    end port_type_gen;
    constant PORT0 :STRING := port_type_gen(MEM_TYPE, MEM_STYLE, "PORT0");
    constant PORT1 :STRING := port_type_gen(MEM_TYPE, MEM_STYLE, "PORT1");

    function or_reduce( V: UNSIGNED) return std_logic is
    variable result: std_logic;
    begin
        for i in V'range loop
            if i = V'left then
                result := V(i);
            else
                result := result OR V(i);
            end if;
            exit when result = '1';
        end loop;
        return result;
    end or_reduce;

begin

    process (address0)
    begin
    address0_tmp <= address0;
    --synthesis translate_off
        if (address0 > DEPTH-1) then
            address0_tmp <= (others => '0');
        else
            address0_tmp <= address0;
        end if;
    --synthesis translate_on
    end process;

    process (address1)
    begin
    address1_tmp <= address1;
    --synthesis translate_off
        if (address1 > DEPTH-1) then
            address1_tmp <= (others => '0');
        else
            address1_tmp <= address1;
        end if;
    --synthesis translate_on
    end process;

    --read port 0
    read_p0_rf : if (PORT0 = "RO" or PORT0 = "RWRF") generate
        process (clk0) begin
            if (clk0'event and clk0 = '1') then
                if (ce0 = '1') then
                    q0 <= mem(to_integer(address0_tmp));
                end if;
            end if;
        end process;
    end generate read_p0_rf;

    read_p0_nc : if (PORT0 = "RWNC") generate
        process (clk0) begin
            if (clk0'event and clk0 = '1') then
                if (ce0 = '1') then
                    if (we0 = (we0'range => '0')) then
                        q0 <= mem(to_integer(address0_tmp));
                    end if;
                end if;
            end if;
        end process;
    end generate read_p0_nc;

    --read port 1
    read_p1_rf : if (PORT1 = "RO" or PORT1 = "RWRF") generate
        process (clk1) begin
            if (clk1'event and clk1 = '1') then
                if (ce1 = '1') then
                    q1 <= mem(to_integer(address1_tmp));
                end if;
            end if;
        end process;
    end generate read_p1_rf;

    read_p1_nc : if (PORT1 = "RWNC") generate
        process (clk1) begin
            if (clk1'event and clk1 = '1') then
                if (ce1 = '1') then
                    if (we1 = (we1'range => '0')) then
                        q1 <= mem(to_integer(address1_tmp));
                    end if;
                end if;
            end if;
        end process;
    end generate read_p1_nc;

    --write port 0
    write_p0 : if (PORT0 /= "RO") generate
        process (clk0)
        begin
            if (clk0'event and clk0 = '1') then
                if (ce0 = '1') then
                for i in 0 to BYTES - 1 loop
                    if (we0(i) = '1') then
                        mem(to_integer(address0_tmp))((i+1)*BYTE_WIDTH-1 downto i*BYTE_WIDTH) := d0((i+1)*BYTE_WIDTH-1 downto i*BYTE_WIDTH);
                    end if;
                end loop;
                end if;
            end if;
        end process;
    end generate write_p0;

    --write port 1
    write_p1 : if (PORT1 /= "RO") generate
        process (clk1)
        begin
            if (clk1'event and clk1 = '1') then
                if (ce1 = '1') then
                for i in 0 to BYTES - 1 loop
                    if (we1(i) = '1') then
                        mem(to_integer(address1_tmp))((i+1)*BYTE_WIDTH-1 downto i*BYTE_WIDTH) := d1((i+1)*BYTE_WIDTH-1 downto i*BYTE_WIDTH);
                    end if;
                end loop;
                end if;
            end if;
        end process;
    end generate write_p1;

end architecture behave;


