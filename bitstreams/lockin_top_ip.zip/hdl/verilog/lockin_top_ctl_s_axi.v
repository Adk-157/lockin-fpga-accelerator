// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module lockin_top_ctl_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 16,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire                          interrupt,
    output wire [31:0]                   ctl,
    output wire [4:0]                    kfix,
    output wire [31:0]                   ph_ref,
    output wire [31:0]                   ph_sig,
    output wire [31:0]                   ph_off,
    output wire [15:0]                   amp,
    output wire [15:0]                   sigma,
    output wire [31:0]                   seed,
    output wire [15:0]                   log_every,
    output wire [15:0]                   x_ext,
    input  wire [31:0]                   out_count,
    input  wire                          out_count_ap_vld,
    input  wire [31:0]                   log_n,
    input  wire                          log_n_ap_vld,
    input  wire [31:0]                   status,
    input  wire                          status_ap_vld,
    input  wire [4:0]                    k_now,
    input  wire                          k_now_ap_vld,
    input  wire [31:0]                   mI_now,
    input  wire                          mI_now_ap_vld,
    input  wire [31:0]                   mQ_now,
    input  wire                          mQ_now_ap_vld,
    input  wire [15:0]                   mag_now,
    input  wire                          mag_now_ap_vld,
    input  wire [12:0]                   log_mem_address0,
    input  wire                          log_mem_ce0,
    input  wire                          log_mem_we0,
    input  wire [31:0]                   log_mem_d0,
    output wire                          ap_start,
    input  wire                          ap_done,
    input  wire                          ap_ready,
    input  wire                          ap_idle
);
//------------------------Address Info-------------------
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read/COR)
//          bit 7  - auto_restart (Read/Write)
//          bit 9  - interrupt (Read)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0 - enable ap_done interrupt (Read/Write)
//          bit 1 - enable ap_ready interrupt (Read/Write)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0 - ap_done (Read/TOW)
//          bit 1 - ap_ready (Read/TOW)
//          others - reserved
// 0x0010 : Data signal of ctl
//          bit 31~0 - ctl[31:0] (Read/Write)
// 0x0014 : reserved
// 0x0018 : Data signal of kfix
//          bit 4~0 - kfix[4:0] (Read/Write)
//          others  - reserved
// 0x001c : reserved
// 0x0020 : Data signal of ph_ref
//          bit 31~0 - ph_ref[31:0] (Read/Write)
// 0x0024 : reserved
// 0x0028 : Data signal of ph_sig
//          bit 31~0 - ph_sig[31:0] (Read/Write)
// 0x002c : reserved
// 0x0030 : Data signal of ph_off
//          bit 31~0 - ph_off[31:0] (Read/Write)
// 0x0034 : reserved
// 0x0038 : Data signal of amp
//          bit 15~0 - amp[15:0] (Read/Write)
//          others   - reserved
// 0x003c : reserved
// 0x0040 : Data signal of sigma
//          bit 15~0 - sigma[15:0] (Read/Write)
//          others   - reserved
// 0x0044 : reserved
// 0x0048 : Data signal of seed
//          bit 31~0 - seed[31:0] (Read/Write)
// 0x004c : reserved
// 0x0050 : Data signal of log_every
//          bit 15~0 - log_every[15:0] (Read/Write)
//          others   - reserved
// 0x0054 : reserved
// 0x0058 : Data signal of x_ext
//          bit 15~0 - x_ext[15:0] (Read/Write)
//          others   - reserved
// 0x005c : reserved
// 0x0060 : Data signal of out_count
//          bit 31~0 - out_count[31:0] (Read)
// 0x0064 : Control signal of out_count
//          bit 0  - out_count_ap_vld (Read/COR)
//          others - reserved
// 0x0070 : Data signal of log_n
//          bit 31~0 - log_n[31:0] (Read)
// 0x0074 : Control signal of log_n
//          bit 0  - log_n_ap_vld (Read/COR)
//          others - reserved
// 0x0080 : Data signal of status
//          bit 31~0 - status[31:0] (Read)
// 0x0084 : Control signal of status
//          bit 0  - status_ap_vld (Read/COR)
//          others - reserved
// 0x0090 : Data signal of k_now
//          bit 4~0 - k_now[4:0] (Read)
//          others  - reserved
// 0x0094 : Control signal of k_now
//          bit 0  - k_now_ap_vld (Read/COR)
//          others - reserved
// 0x00a0 : Data signal of mI_now
//          bit 31~0 - mI_now[31:0] (Read)
// 0x00a4 : Control signal of mI_now
//          bit 0  - mI_now_ap_vld (Read/COR)
//          others - reserved
// 0x00b0 : Data signal of mQ_now
//          bit 31~0 - mQ_now[31:0] (Read)
// 0x00b4 : Control signal of mQ_now
//          bit 0  - mQ_now_ap_vld (Read/COR)
//          others - reserved
// 0x00c0 : Data signal of mag_now
//          bit 15~0 - mag_now[15:0] (Read)
//          others   - reserved
// 0x00c4 : Control signal of mag_now
//          bit 0  - mag_now_ap_vld (Read/COR)
//          others - reserved
// 0x8000 ~
// 0xffff : Memory 'log_mem' (8192 * 32b)
//          Word n : bit [31:0] - log_mem[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_AP_CTRL          = 16'h0000,
    ADDR_GIE              = 16'h0004,
    ADDR_IER              = 16'h0008,
    ADDR_ISR              = 16'h000c,
    ADDR_CTL_DATA_0       = 16'h0010,
    ADDR_CTL_CTRL         = 16'h0014,
    ADDR_KFIX_DATA_0      = 16'h0018,
    ADDR_KFIX_CTRL        = 16'h001c,
    ADDR_PH_REF_DATA_0    = 16'h0020,
    ADDR_PH_REF_CTRL      = 16'h0024,
    ADDR_PH_SIG_DATA_0    = 16'h0028,
    ADDR_PH_SIG_CTRL      = 16'h002c,
    ADDR_PH_OFF_DATA_0    = 16'h0030,
    ADDR_PH_OFF_CTRL      = 16'h0034,
    ADDR_AMP_DATA_0       = 16'h0038,
    ADDR_AMP_CTRL         = 16'h003c,
    ADDR_SIGMA_DATA_0     = 16'h0040,
    ADDR_SIGMA_CTRL       = 16'h0044,
    ADDR_SEED_DATA_0      = 16'h0048,
    ADDR_SEED_CTRL        = 16'h004c,
    ADDR_LOG_EVERY_DATA_0 = 16'h0050,
    ADDR_LOG_EVERY_CTRL   = 16'h0054,
    ADDR_X_EXT_DATA_0     = 16'h0058,
    ADDR_X_EXT_CTRL       = 16'h005c,
    ADDR_OUT_COUNT_DATA_0 = 16'h0060,
    ADDR_OUT_COUNT_CTRL   = 16'h0064,
    ADDR_LOG_N_DATA_0     = 16'h0070,
    ADDR_LOG_N_CTRL       = 16'h0074,
    ADDR_STATUS_DATA_0    = 16'h0080,
    ADDR_STATUS_CTRL      = 16'h0084,
    ADDR_K_NOW_DATA_0     = 16'h0090,
    ADDR_K_NOW_CTRL       = 16'h0094,
    ADDR_MI_NOW_DATA_0    = 16'h00a0,
    ADDR_MI_NOW_CTRL      = 16'h00a4,
    ADDR_MQ_NOW_DATA_0    = 16'h00b0,
    ADDR_MQ_NOW_CTRL      = 16'h00b4,
    ADDR_MAG_NOW_DATA_0   = 16'h00c0,
    ADDR_MAG_NOW_CTRL     = 16'h00c4,
    ADDR_LOG_MEM_BASE     = 16'h8000,
    ADDR_LOG_MEM_HIGH     = 16'hffff,
    WRIDLE                = 2'd0,
    WRDATA                = 2'd1,
    WRRESP                = 2'd2,
    WRRESET               = 2'd3,
    RDIDLE                = 2'd0,
    RDDATA                = 2'd1,
    RDRESET               = 2'd2,
    ADDR_BITS                = 16;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg                           int_ap_idle;
    reg                           int_ap_ready = 1'b0;
    wire                          task_ap_ready;
    reg                           int_ap_done = 1'b0;
    wire                          task_ap_done;
    reg                           int_task_ap_done = 1'b0;
    reg                           int_ap_start = 1'b0;
    reg                           int_interrupt = 1'b0;
    reg                           int_auto_restart = 1'b0;
    reg                           auto_restart_status = 1'b0;
    wire                          auto_restart_done;
    reg                           int_gie = 1'b0;
    reg  [1:0]                    int_ier = 2'b0;
    reg  [1:0]                    int_isr = 2'b0;
    reg  [31:0]                   int_ctl = 'b0;
    reg  [4:0]                    int_kfix = 'b0;
    reg  [31:0]                   int_ph_ref = 'b0;
    reg  [31:0]                   int_ph_sig = 'b0;
    reg  [31:0]                   int_ph_off = 'b0;
    reg  [15:0]                   int_amp = 'b0;
    reg  [15:0]                   int_sigma = 'b0;
    reg  [31:0]                   int_seed = 'b0;
    reg  [15:0]                   int_log_every = 'b0;
    reg  [15:0]                   int_x_ext = 'b0;
    reg                           int_out_count_ap_vld;
    reg  [31:0]                   int_out_count = 'b0;
    reg                           int_log_n_ap_vld;
    reg  [31:0]                   int_log_n = 'b0;
    reg                           int_status_ap_vld;
    reg  [31:0]                   int_status = 'b0;
    reg                           int_k_now_ap_vld;
    reg  [4:0]                    int_k_now = 'b0;
    reg                           int_mI_now_ap_vld;
    reg  [31:0]                   int_mI_now = 'b0;
    reg                           int_mQ_now_ap_vld;
    reg  [31:0]                   int_mQ_now = 'b0;
    reg                           int_mag_now_ap_vld;
    reg  [15:0]                   int_mag_now = 'b0;
    // memory signals
    wire [12:0]                   int_log_mem_address0;
    wire                          int_log_mem_ce0;
    wire [3:0]                    int_log_mem_be0;
    wire [31:0]                   int_log_mem_d0;
    wire [12:0]                   int_log_mem_address1;
    wire                          int_log_mem_ce1;
    wire [31:0]                   int_log_mem_q1;
    reg                           int_log_mem_read;
    reg                           int_log_mem_write;

//------------------------Instantiation------------------
// int_log_mem
lockin_top_ctl_s_axi_ram #(
    .MEM_STYLE ( "auto" ),
    .MEM_TYPE  ( "S2P" ),
    .BYTES     ( 4 ),
    .DEPTH     ( 8192 )
) int_log_mem (
    .clk0      ( ACLK ),
    .address0  ( int_log_mem_address0 ),
    .ce0       ( int_log_mem_ce0 ),
    .we0       ( int_log_mem_be0 ),
    .d0        ( int_log_mem_d0 ),
    .q0        (  ),
    .clk1      ( ACLK ),
    .address1  ( int_log_mem_address1 ),
    .ce1       ( int_log_mem_ce1 ),
    .we1       ( {4{1'b0}} ),
    .d1        ( {32{1'b0}} ),
    .q1        ( int_log_mem_q1 )
);


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA) && (!ar_hs);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (w_hs)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= AWADDR[ADDR_BITS-1:0];
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA) & !int_log_mem_read;
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_AP_CTRL: begin
                    rdata[0] <= int_ap_start;
                    rdata[1] <= int_task_ap_done;
                    rdata[2] <= int_ap_idle;
                    rdata[3] <= int_ap_ready;
                    rdata[7] <= int_auto_restart;
                    rdata[9] <= int_interrupt;
                end
                ADDR_GIE: begin
                    rdata <= int_gie;
                end
                ADDR_IER: begin
                    rdata <= int_ier;
                end
                ADDR_ISR: begin
                    rdata <= int_isr;
                end
                ADDR_CTL_DATA_0: begin
                    rdata <= int_ctl[31:0];
                end
                ADDR_KFIX_DATA_0: begin
                    rdata <= int_kfix[4:0];
                end
                ADDR_PH_REF_DATA_0: begin
                    rdata <= int_ph_ref[31:0];
                end
                ADDR_PH_SIG_DATA_0: begin
                    rdata <= int_ph_sig[31:0];
                end
                ADDR_PH_OFF_DATA_0: begin
                    rdata <= int_ph_off[31:0];
                end
                ADDR_AMP_DATA_0: begin
                    rdata <= int_amp[15:0];
                end
                ADDR_SIGMA_DATA_0: begin
                    rdata <= int_sigma[15:0];
                end
                ADDR_SEED_DATA_0: begin
                    rdata <= int_seed[31:0];
                end
                ADDR_LOG_EVERY_DATA_0: begin
                    rdata <= int_log_every[15:0];
                end
                ADDR_X_EXT_DATA_0: begin
                    rdata <= int_x_ext[15:0];
                end
                ADDR_OUT_COUNT_DATA_0: begin
                    rdata <= int_out_count[31:0];
                end
                ADDR_OUT_COUNT_CTRL: begin
                    rdata[0] <= int_out_count_ap_vld;
                end
                ADDR_LOG_N_DATA_0: begin
                    rdata <= int_log_n[31:0];
                end
                ADDR_LOG_N_CTRL: begin
                    rdata[0] <= int_log_n_ap_vld;
                end
                ADDR_STATUS_DATA_0: begin
                    rdata <= int_status[31:0];
                end
                ADDR_STATUS_CTRL: begin
                    rdata[0] <= int_status_ap_vld;
                end
                ADDR_K_NOW_DATA_0: begin
                    rdata <= int_k_now[4:0];
                end
                ADDR_K_NOW_CTRL: begin
                    rdata[0] <= int_k_now_ap_vld;
                end
                ADDR_MI_NOW_DATA_0: begin
                    rdata <= int_mI_now[31:0];
                end
                ADDR_MI_NOW_CTRL: begin
                    rdata[0] <= int_mI_now_ap_vld;
                end
                ADDR_MQ_NOW_DATA_0: begin
                    rdata <= int_mQ_now[31:0];
                end
                ADDR_MQ_NOW_CTRL: begin
                    rdata[0] <= int_mQ_now_ap_vld;
                end
                ADDR_MAG_NOW_DATA_0: begin
                    rdata <= int_mag_now[15:0];
                end
                ADDR_MAG_NOW_CTRL: begin
                    rdata[0] <= int_mag_now_ap_vld;
                end
            endcase
        end
        else if (int_log_mem_read) begin
            rdata <= int_log_mem_q1;
        end
    end
end


//------------------------Register logic-----------------
assign interrupt         = int_interrupt;
assign ap_start          = int_ap_start;
assign task_ap_done      = (ap_done && !auto_restart_status) || auto_restart_done;
assign task_ap_ready     = ap_ready && !int_auto_restart;
assign auto_restart_done = auto_restart_status && (ap_idle && !int_ap_idle);
assign ctl               = int_ctl;
assign kfix              = int_kfix;
assign ph_ref            = int_ph_ref;
assign ph_sig            = int_ph_sig;
assign ph_off            = int_ph_off;
assign amp               = int_amp;
assign sigma             = int_sigma;
assign seed              = int_seed;
assign log_every         = int_log_every;
assign x_ext             = int_x_ext;
// int_interrupt
always @(posedge ACLK) begin
    if (ARESET)
        int_interrupt <= 1'b0;
    else if (ACLK_EN) begin
        if (int_gie && (|int_isr))
            int_interrupt <= 1'b1;
        else
            int_interrupt <= 1'b0;
    end
end

// int_ap_start
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_start <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0] && WDATA[0])
            int_ap_start <= 1'b1;
        else if (ap_ready)
            int_ap_start <= int_auto_restart; // clear on handshake/auto restart
    end
end

// int_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_done <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_done <= ap_done;
    end
end

// int_task_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_task_ap_done <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_done)
            int_task_ap_done <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_task_ap_done <= 1'b0; // clear on read
    end
end

// int_ap_idle
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_idle <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_idle <= ap_idle;
    end
end

// int_ap_ready
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_ready <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_ready)
            int_ap_ready <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_ap_ready <= 1'b0;
    end
end

// int_auto_restart
always @(posedge ACLK) begin
    if (ARESET)
        int_auto_restart <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0])
            int_auto_restart <=  WDATA[7];
    end
end

// auto_restart_status
always @(posedge ACLK) begin
    if (ARESET)
        auto_restart_status <= 1'b0;
    else if (ACLK_EN) begin
        if (int_auto_restart)
            auto_restart_status <= 1'b1;
        else if (ap_idle)
            auto_restart_status <= 1'b0;
    end
end

// int_gie
always @(posedge ACLK) begin
    if (ARESET)
        int_gie <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_GIE && WSTRB[0])
            int_gie <= WDATA[0];
    end
end

// int_ier
always @(posedge ACLK) begin
    if (ARESET)
        int_ier <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IER && WSTRB[0])
            int_ier <= WDATA[1:0];
    end
end

// int_isr[0]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[0] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[0] & ap_done)
            int_isr[0] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[0] <= int_isr[0] ^ WDATA[0]; // toggle on write
    end
end

// int_isr[1]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[1] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[1] & ap_ready)
            int_isr[1] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[1] <= int_isr[1] ^ WDATA[1]; // toggle on write
    end
end

// int_ctl[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ctl[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CTL_DATA_0)
            int_ctl[31:0] <= (WDATA[31:0] & wmask) | (int_ctl[31:0] & ~wmask);
    end
end

// int_kfix[4:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_kfix[4:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_KFIX_DATA_0)
            int_kfix[4:0] <= (WDATA[31:0] & wmask) | (int_kfix[4:0] & ~wmask);
    end
end

// int_ph_ref[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ph_ref[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PH_REF_DATA_0)
            int_ph_ref[31:0] <= (WDATA[31:0] & wmask) | (int_ph_ref[31:0] & ~wmask);
    end
end

// int_ph_sig[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ph_sig[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PH_SIG_DATA_0)
            int_ph_sig[31:0] <= (WDATA[31:0] & wmask) | (int_ph_sig[31:0] & ~wmask);
    end
end

// int_ph_off[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ph_off[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PH_OFF_DATA_0)
            int_ph_off[31:0] <= (WDATA[31:0] & wmask) | (int_ph_off[31:0] & ~wmask);
    end
end

// int_amp[15:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_amp[15:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AMP_DATA_0)
            int_amp[15:0] <= (WDATA[31:0] & wmask) | (int_amp[15:0] & ~wmask);
    end
end

// int_sigma[15:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sigma[15:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SIGMA_DATA_0)
            int_sigma[15:0] <= (WDATA[31:0] & wmask) | (int_sigma[15:0] & ~wmask);
    end
end

// int_seed[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_seed[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEED_DATA_0)
            int_seed[31:0] <= (WDATA[31:0] & wmask) | (int_seed[31:0] & ~wmask);
    end
end

// int_log_every[15:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_log_every[15:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_LOG_EVERY_DATA_0)
            int_log_every[15:0] <= (WDATA[31:0] & wmask) | (int_log_every[15:0] & ~wmask);
    end
end

// int_x_ext[15:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_ext[15:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_EXT_DATA_0)
            int_x_ext[15:0] <= (WDATA[31:0] & wmask) | (int_x_ext[15:0] & ~wmask);
    end
end

// int_out_count
always @(posedge ACLK) begin
    if (ARESET)
        int_out_count <= 0;
    else if (ACLK_EN) begin
        if (out_count_ap_vld)
            int_out_count <= out_count;
    end
end

// int_out_count_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_out_count_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (out_count_ap_vld)
            int_out_count_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_OUT_COUNT_CTRL)
            int_out_count_ap_vld <= 1'b0; // clear on read
    end
end

// int_log_n
always @(posedge ACLK) begin
    if (ARESET)
        int_log_n <= 0;
    else if (ACLK_EN) begin
        if (log_n_ap_vld)
            int_log_n <= log_n;
    end
end

// int_log_n_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_log_n_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (log_n_ap_vld)
            int_log_n_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_LOG_N_CTRL)
            int_log_n_ap_vld <= 1'b0; // clear on read
    end
end

// int_status
always @(posedge ACLK) begin
    if (ARESET)
        int_status <= 0;
    else if (ACLK_EN) begin
        if (status_ap_vld)
            int_status <= status;
    end
end

// int_status_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_status_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (status_ap_vld)
            int_status_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_STATUS_CTRL)
            int_status_ap_vld <= 1'b0; // clear on read
    end
end

// int_k_now
always @(posedge ACLK) begin
    if (ARESET)
        int_k_now <= 0;
    else if (ACLK_EN) begin
        if (k_now_ap_vld)
            int_k_now <= k_now;
    end
end

// int_k_now_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_k_now_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (k_now_ap_vld)
            int_k_now_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_K_NOW_CTRL)
            int_k_now_ap_vld <= 1'b0; // clear on read
    end
end

// int_mI_now
always @(posedge ACLK) begin
    if (ARESET)
        int_mI_now <= 0;
    else if (ACLK_EN) begin
        if (mI_now_ap_vld)
            int_mI_now <= mI_now;
    end
end

// int_mI_now_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_mI_now_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (mI_now_ap_vld)
            int_mI_now_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_MI_NOW_CTRL)
            int_mI_now_ap_vld <= 1'b0; // clear on read
    end
end

// int_mQ_now
always @(posedge ACLK) begin
    if (ARESET)
        int_mQ_now <= 0;
    else if (ACLK_EN) begin
        if (mQ_now_ap_vld)
            int_mQ_now <= mQ_now;
    end
end

// int_mQ_now_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_mQ_now_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (mQ_now_ap_vld)
            int_mQ_now_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_MQ_NOW_CTRL)
            int_mQ_now_ap_vld <= 1'b0; // clear on read
    end
end

// int_mag_now
always @(posedge ACLK) begin
    if (ARESET)
        int_mag_now <= 0;
    else if (ACLK_EN) begin
        if (mag_now_ap_vld)
            int_mag_now <= mag_now;
    end
end

// int_mag_now_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_mag_now_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (mag_now_ap_vld)
            int_mag_now_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_MAG_NOW_CTRL)
            int_mag_now_ap_vld <= 1'b0; // clear on read
    end
end

//synthesis translate_off
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (int_gie & ~int_isr[0] & int_ier[0] & ap_done)
            $display ("// Interrupt Monitor : interrupt for ap_done detected @ \"%0t\"", $time);
        if (int_gie & ~int_isr[1] & int_ier[1] & ap_ready)
            $display ("// Interrupt Monitor : interrupt for ap_ready detected @ \"%0t\"", $time);
    end
end
//synthesis translate_on

//------------------------Memory logic-------------------
// log_mem
assign int_log_mem_address0 = log_mem_address0;
assign int_log_mem_ce0      = log_mem_ce0;
assign int_log_mem_be0      = {4{log_mem_we0}};
assign int_log_mem_d0       = log_mem_d0;
assign int_log_mem_address1 = ar_hs? raddr[14:2] : waddr[14:2];
assign int_log_mem_ce1      = ar_hs | (int_log_mem_write & WVALID);
// int_log_mem_read
always @(posedge ACLK) begin
    if (ARESET)
        int_log_mem_read <= 1'b0;
    else if (ACLK_EN) begin
        if (ar_hs && raddr >= ADDR_LOG_MEM_BASE && raddr <= ADDR_LOG_MEM_HIGH)
            int_log_mem_read <= 1'b1;
        else
            int_log_mem_read <= 1'b0;
    end
end


endmodule


`timescale 1ns/1ps

module lockin_top_ctl_s_axi_ram
#(parameter
    MEM_STYLE = "auto",
    MEM_TYPE  = "S2P",
    BYTES  = 4,
    DEPTH  = 256,
    AWIDTH = log2(DEPTH)
) (
    input  wire               clk0,
    input  wire [AWIDTH-1:0]  address0,
    input  wire               ce0,
    input  wire [BYTES-1:0]   we0,
    input  wire [BYTES*8-1:0] d0,
    output reg  [BYTES*8-1:0] q0,
    input  wire               clk1,
    input  wire [AWIDTH-1:0]  address1,
    input  wire               ce1,
    input  wire [BYTES-1:0]   we1,
    input  wire [BYTES*8-1:0] d1,
    output reg  [BYTES*8-1:0] q1
);
//------------------------ Parameters -------------------
localparam
    BYTE_WIDTH = 8,
    PORT0 = (MEM_TYPE == "S2P") ? "WO" : ((MEM_TYPE == "2P") ? "RO" : "RW"),
    PORT1 = (MEM_TYPE == "S2P") ? "RO" : "RW";
//------------------------Local signal-------------------
(* ram_style = MEM_STYLE*)
reg  [BYTES*8-1:0] mem[0:DEPTH-1];
wire re0, re1;
//------------------------Task and function--------------
function integer log2;
    input integer x;
    integer n, m;
begin
    n = 1;
    m = 2;
    while (m < x) begin
        n = n + 1;
        m = m * 2;
    end
    log2 = n;
end
endfunction
//------------------------Body---------------------------
generate
    if (MEM_STYLE == "hls_ultra" && PORT0 == "RW") begin
        assign re0 = ce0 & ~|we0;
    end else begin
        assign re0 = ce0;
    end
endgenerate

generate
    if (MEM_STYLE == "hls_ultra" && PORT1 == "RW") begin
        assign re1 = ce1 & ~|we1;
    end else begin
        assign re1 = ce1;
    end
endgenerate

// read port 0
generate if (PORT0 != "WO") begin
    always @(posedge clk0) begin
        if (re0) q0 <= mem[address0];
    end
end
endgenerate

// read port 1
generate if (PORT1 != "WO") begin
    always @(posedge clk1) begin
        if (re1) q1 <= mem[address1];
    end
end
endgenerate

integer i;
// write port 0
generate if (PORT0 != "RO") begin
    always @(posedge clk0) begin
        if (ce0)
        for (i = 0; i < BYTES; i = i + 1)
            if (we0[i])
                mem[address0][i*BYTE_WIDTH +: BYTE_WIDTH] <= d0[i*BYTE_WIDTH +: BYTE_WIDTH];
    end
end
endgenerate

// write port 1
generate if (PORT1 != "RO") begin
    always @(posedge clk1) begin
        if (ce1)
        for (i = 0; i < BYTES; i = i + 1)
            if (we1[i])
                mem[address1][i*BYTE_WIDTH +: BYTE_WIDTH] <= d1[i*BYTE_WIDTH +: BYTE_WIDTH];
    end
end
endgenerate

endmodule

