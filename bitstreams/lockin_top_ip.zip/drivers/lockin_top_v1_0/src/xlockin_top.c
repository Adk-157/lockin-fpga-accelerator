// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xlockin_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLockin_top_CfgInitialize(XLockin_top *InstancePtr, XLockin_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctl_BaseAddress = ConfigPtr->Ctl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLockin_top_Start(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL) & 0x80;
    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLockin_top_IsDone(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLockin_top_IsIdle(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLockin_top_IsReady(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLockin_top_EnableAutoRestart(XLockin_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL, 0x80);
}

void XLockin_top_DisableAutoRestart(XLockin_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AP_CTRL, 0);
}

void XLockin_top_Set_ctl(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_CTL_DATA, Data);
}

u32 XLockin_top_Get_ctl(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_CTL_DATA);
    return Data;
}

void XLockin_top_Set_kfix(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_KFIX_DATA, Data);
}

u32 XLockin_top_Get_kfix(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_KFIX_DATA);
    return Data;
}

void XLockin_top_Set_ph_ref(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_REF_DATA, Data);
}

u32 XLockin_top_Get_ph_ref(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_REF_DATA);
    return Data;
}

void XLockin_top_Set_ph_sig(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_SIG_DATA, Data);
}

u32 XLockin_top_Get_ph_sig(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_SIG_DATA);
    return Data;
}

void XLockin_top_Set_ph_off(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_OFF_DATA, Data);
}

u32 XLockin_top_Get_ph_off(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_PH_OFF_DATA);
    return Data;
}

void XLockin_top_Set_amp(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AMP_DATA, Data);
}

u32 XLockin_top_Get_amp(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_AMP_DATA);
    return Data;
}

void XLockin_top_Set_sigma(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_SIGMA_DATA, Data);
}

u32 XLockin_top_Get_sigma(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_SIGMA_DATA);
    return Data;
}

void XLockin_top_Set_seed(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_SEED_DATA, Data);
}

u32 XLockin_top_Get_seed(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_SEED_DATA);
    return Data;
}

void XLockin_top_Set_log_every(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_LOG_EVERY_DATA, Data);
}

u32 XLockin_top_Get_log_every(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_LOG_EVERY_DATA);
    return Data;
}

void XLockin_top_Set_x_ext(XLockin_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_X_EXT_DATA, Data);
}

u32 XLockin_top_Get_x_ext(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_X_EXT_DATA);
    return Data;
}

u32 XLockin_top_Get_out_count(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_OUT_COUNT_DATA);
    return Data;
}

u32 XLockin_top_Get_out_count_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_OUT_COUNT_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_log_n(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_LOG_N_DATA);
    return Data;
}

u32 XLockin_top_Get_log_n_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_LOG_N_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_status(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_STATUS_DATA);
    return Data;
}

u32 XLockin_top_Get_status_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_STATUS_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_k_now(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_K_NOW_DATA);
    return Data;
}

u32 XLockin_top_Get_k_now_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_K_NOW_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_mI_now(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MI_NOW_DATA);
    return Data;
}

u32 XLockin_top_Get_mI_now_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MI_NOW_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_mQ_now(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MQ_NOW_DATA);
    return Data;
}

u32 XLockin_top_Get_mQ_now_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MQ_NOW_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_mag_now(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MAG_NOW_DATA);
    return Data;
}

u32 XLockin_top_Get_mag_now_vld(XLockin_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_MAG_NOW_CTRL);
    return Data & 0x1;
}

u32 XLockin_top_Get_log_mem_BaseAddress(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE);
}

u32 XLockin_top_Get_log_mem_HighAddress(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH);
}

u32 XLockin_top_Get_log_mem_TotalBytes(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH - XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + 1);
}

u32 XLockin_top_Get_log_mem_BitWidth(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLOCKIN_TOP_CTL_WIDTH_LOG_MEM;
}

u32 XLockin_top_Get_log_mem_Depth(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLOCKIN_TOP_CTL_DEPTH_LOG_MEM;
}

u32 XLockin_top_Write_log_mem_Words(XLockin_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH - XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XLockin_top_Read_log_mem_Words(XLockin_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH - XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + (offset + i)*4);
    }
    return length;
}

u32 XLockin_top_Write_log_mem_Bytes(XLockin_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH - XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XLockin_top_Read_log_mem_Bytes(XLockin_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH - XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Ctl_BaseAddress + XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE + offset + i);
    }
    return length;
}

void XLockin_top_InterruptGlobalEnable(XLockin_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_GIE, 1);
}

void XLockin_top_InterruptGlobalDisable(XLockin_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_GIE, 0);
}

void XLockin_top_InterruptEnable(XLockin_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_IER);
    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_IER, Register | Mask);
}

void XLockin_top_InterruptDisable(XLockin_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_IER);
    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_IER, Register & (~Mask));
}

void XLockin_top_InterruptClear(XLockin_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLockin_top_WriteReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_ISR, Mask);
}

u32 XLockin_top_InterruptGetEnabled(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_IER);
}

u32 XLockin_top_InterruptGetStatus(XLockin_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLockin_top_ReadReg(InstancePtr->Ctl_BaseAddress, XLOCKIN_TOP_CTL_ADDR_ISR);
}

