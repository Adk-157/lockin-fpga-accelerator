// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XLOCKIN_TOP_H
#define XLOCKIN_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlockin_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Ctl_BaseAddress;
} XLockin_top_Config;
#endif

typedef struct {
    u64 Ctl_BaseAddress;
    u32 IsReady;
} XLockin_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLockin_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLockin_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLockin_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLockin_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XLockin_top_Initialize(XLockin_top *InstancePtr, u16 DeviceId);
XLockin_top_Config* XLockin_top_LookupConfig(u16 DeviceId);
int XLockin_top_CfgInitialize(XLockin_top *InstancePtr, XLockin_top_Config *ConfigPtr);
#else
int XLockin_top_Initialize(XLockin_top *InstancePtr, const char* InstanceName);
int XLockin_top_Release(XLockin_top *InstancePtr);
#endif

void XLockin_top_Start(XLockin_top *InstancePtr);
u32 XLockin_top_IsDone(XLockin_top *InstancePtr);
u32 XLockin_top_IsIdle(XLockin_top *InstancePtr);
u32 XLockin_top_IsReady(XLockin_top *InstancePtr);
void XLockin_top_EnableAutoRestart(XLockin_top *InstancePtr);
void XLockin_top_DisableAutoRestart(XLockin_top *InstancePtr);

void XLockin_top_Set_ctl(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_ctl(XLockin_top *InstancePtr);
void XLockin_top_Set_kfix(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_kfix(XLockin_top *InstancePtr);
void XLockin_top_Set_ph_ref(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_ph_ref(XLockin_top *InstancePtr);
void XLockin_top_Set_ph_sig(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_ph_sig(XLockin_top *InstancePtr);
void XLockin_top_Set_ph_off(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_ph_off(XLockin_top *InstancePtr);
void XLockin_top_Set_amp(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_amp(XLockin_top *InstancePtr);
void XLockin_top_Set_sigma(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_sigma(XLockin_top *InstancePtr);
void XLockin_top_Set_seed(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_seed(XLockin_top *InstancePtr);
void XLockin_top_Set_log_every(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_log_every(XLockin_top *InstancePtr);
void XLockin_top_Set_x_ext(XLockin_top *InstancePtr, u32 Data);
u32 XLockin_top_Get_x_ext(XLockin_top *InstancePtr);
u32 XLockin_top_Get_out_count(XLockin_top *InstancePtr);
u32 XLockin_top_Get_out_count_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_n(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_n_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_status(XLockin_top *InstancePtr);
u32 XLockin_top_Get_status_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_k_now(XLockin_top *InstancePtr);
u32 XLockin_top_Get_k_now_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mI_now(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mI_now_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mQ_now(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mQ_now_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mag_now(XLockin_top *InstancePtr);
u32 XLockin_top_Get_mag_now_vld(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_mem_BaseAddress(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_mem_HighAddress(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_mem_TotalBytes(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_mem_BitWidth(XLockin_top *InstancePtr);
u32 XLockin_top_Get_log_mem_Depth(XLockin_top *InstancePtr);
u32 XLockin_top_Write_log_mem_Words(XLockin_top *InstancePtr, int offset, word_type *data, int length);
u32 XLockin_top_Read_log_mem_Words(XLockin_top *InstancePtr, int offset, word_type *data, int length);
u32 XLockin_top_Write_log_mem_Bytes(XLockin_top *InstancePtr, int offset, char *data, int length);
u32 XLockin_top_Read_log_mem_Bytes(XLockin_top *InstancePtr, int offset, char *data, int length);

void XLockin_top_InterruptGlobalEnable(XLockin_top *InstancePtr);
void XLockin_top_InterruptGlobalDisable(XLockin_top *InstancePtr);
void XLockin_top_InterruptEnable(XLockin_top *InstancePtr, u32 Mask);
void XLockin_top_InterruptDisable(XLockin_top *InstancePtr, u32 Mask);
void XLockin_top_InterruptClear(XLockin_top *InstancePtr, u32 Mask);
u32 XLockin_top_InterruptGetEnabled(XLockin_top *InstancePtr);
u32 XLockin_top_InterruptGetStatus(XLockin_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
