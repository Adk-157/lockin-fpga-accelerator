// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// ctl
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read/COR)
//          bit 7  - auto_restart (Read/Write)
//          bit 9  - interrupt (Read)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0 - enable ap_done interrupt (Read/Write)
//          bit 1 - enable ap_ready interrupt (Read/Write)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0 - ap_done (Read/TOW)
//          bit 1 - ap_ready (Read/TOW)
//          others - reserved
// 0x0010 : Data signal of ctl
//          bit 31~0 - ctl[31:0] (Read/Write)
// 0x0014 : reserved
// 0x0018 : Data signal of kfix
//          bit 4~0 - kfix[4:0] (Read/Write)
//          others  - reserved
// 0x001c : reserved
// 0x0020 : Data signal of ph_ref
//          bit 31~0 - ph_ref[31:0] (Read/Write)
// 0x0024 : reserved
// 0x0028 : Data signal of ph_sig
//          bit 31~0 - ph_sig[31:0] (Read/Write)
// 0x002c : reserved
// 0x0030 : Data signal of ph_off
//          bit 31~0 - ph_off[31:0] (Read/Write)
// 0x0034 : reserved
// 0x0038 : Data signal of amp
//          bit 15~0 - amp[15:0] (Read/Write)
//          others   - reserved
// 0x003c : reserved
// 0x0040 : Data signal of sigma
//          bit 15~0 - sigma[15:0] (Read/Write)
//          others   - reserved
// 0x0044 : reserved
// 0x0048 : Data signal of seed
//          bit 31~0 - seed[31:0] (Read/Write)
// 0x004c : reserved
// 0x0050 : Data signal of log_every
//          bit 15~0 - log_every[15:0] (Read/Write)
//          others   - reserved
// 0x0054 : reserved
// 0x0058 : Data signal of x_ext
//          bit 15~0 - x_ext[15:0] (Read/Write)
//          others   - reserved
// 0x005c : reserved
// 0x0060 : Data signal of out_count
//          bit 31~0 - out_count[31:0] (Read)
// 0x0064 : Control signal of out_count
//          bit 0  - out_count_ap_vld (Read/COR)
//          others - reserved
// 0x0070 : Data signal of log_n
//          bit 31~0 - log_n[31:0] (Read)
// 0x0074 : Control signal of log_n
//          bit 0  - log_n_ap_vld (Read/COR)
//          others - reserved
// 0x0080 : Data signal of status
//          bit 31~0 - status[31:0] (Read)
// 0x0084 : Control signal of status
//          bit 0  - status_ap_vld (Read/COR)
//          others - reserved
// 0x0090 : Data signal of k_now
//          bit 4~0 - k_now[4:0] (Read)
//          others  - reserved
// 0x0094 : Control signal of k_now
//          bit 0  - k_now_ap_vld (Read/COR)
//          others - reserved
// 0x00a0 : Data signal of mI_now
//          bit 31~0 - mI_now[31:0] (Read)
// 0x00a4 : Control signal of mI_now
//          bit 0  - mI_now_ap_vld (Read/COR)
//          others - reserved
// 0x00b0 : Data signal of mQ_now
//          bit 31~0 - mQ_now[31:0] (Read)
// 0x00b4 : Control signal of mQ_now
//          bit 0  - mQ_now_ap_vld (Read/COR)
//          others - reserved
// 0x00c0 : Data signal of mag_now
//          bit 15~0 - mag_now[15:0] (Read)
//          others   - reserved
// 0x00c4 : Control signal of mag_now
//          bit 0  - mag_now_ap_vld (Read/COR)
//          others - reserved
// 0x8000 ~
// 0xffff : Memory 'log_mem' (8192 * 32b)
//          Word n : bit [31:0] - log_mem[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLOCKIN_TOP_CTL_ADDR_AP_CTRL        0x0000
#define XLOCKIN_TOP_CTL_ADDR_GIE            0x0004
#define XLOCKIN_TOP_CTL_ADDR_IER            0x0008
#define XLOCKIN_TOP_CTL_ADDR_ISR            0x000c
#define XLOCKIN_TOP_CTL_ADDR_CTL_DATA       0x0010
#define XLOCKIN_TOP_CTL_BITS_CTL_DATA       32
#define XLOCKIN_TOP_CTL_ADDR_KFIX_DATA      0x0018
#define XLOCKIN_TOP_CTL_BITS_KFIX_DATA      5
#define XLOCKIN_TOP_CTL_ADDR_PH_REF_DATA    0x0020
#define XLOCKIN_TOP_CTL_BITS_PH_REF_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_PH_SIG_DATA    0x0028
#define XLOCKIN_TOP_CTL_BITS_PH_SIG_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_PH_OFF_DATA    0x0030
#define XLOCKIN_TOP_CTL_BITS_PH_OFF_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_AMP_DATA       0x0038
#define XLOCKIN_TOP_CTL_BITS_AMP_DATA       16
#define XLOCKIN_TOP_CTL_ADDR_SIGMA_DATA     0x0040
#define XLOCKIN_TOP_CTL_BITS_SIGMA_DATA     16
#define XLOCKIN_TOP_CTL_ADDR_SEED_DATA      0x0048
#define XLOCKIN_TOP_CTL_BITS_SEED_DATA      32
#define XLOCKIN_TOP_CTL_ADDR_LOG_EVERY_DATA 0x0050
#define XLOCKIN_TOP_CTL_BITS_LOG_EVERY_DATA 16
#define XLOCKIN_TOP_CTL_ADDR_X_EXT_DATA     0x0058
#define XLOCKIN_TOP_CTL_BITS_X_EXT_DATA     16
#define XLOCKIN_TOP_CTL_ADDR_OUT_COUNT_DATA 0x0060
#define XLOCKIN_TOP_CTL_BITS_OUT_COUNT_DATA 32
#define XLOCKIN_TOP_CTL_ADDR_OUT_COUNT_CTRL 0x0064
#define XLOCKIN_TOP_CTL_ADDR_LOG_N_DATA     0x0070
#define XLOCKIN_TOP_CTL_BITS_LOG_N_DATA     32
#define XLOCKIN_TOP_CTL_ADDR_LOG_N_CTRL     0x0074
#define XLOCKIN_TOP_CTL_ADDR_STATUS_DATA    0x0080
#define XLOCKIN_TOP_CTL_BITS_STATUS_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_STATUS_CTRL    0x0084
#define XLOCKIN_TOP_CTL_ADDR_K_NOW_DATA     0x0090
#define XLOCKIN_TOP_CTL_BITS_K_NOW_DATA     5
#define XLOCKIN_TOP_CTL_ADDR_K_NOW_CTRL     0x0094
#define XLOCKIN_TOP_CTL_ADDR_MI_NOW_DATA    0x00a0
#define XLOCKIN_TOP_CTL_BITS_MI_NOW_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_MI_NOW_CTRL    0x00a4
#define XLOCKIN_TOP_CTL_ADDR_MQ_NOW_DATA    0x00b0
#define XLOCKIN_TOP_CTL_BITS_MQ_NOW_DATA    32
#define XLOCKIN_TOP_CTL_ADDR_MQ_NOW_CTRL    0x00b4
#define XLOCKIN_TOP_CTL_ADDR_MAG_NOW_DATA   0x00c0
#define XLOCKIN_TOP_CTL_BITS_MAG_NOW_DATA   16
#define XLOCKIN_TOP_CTL_ADDR_MAG_NOW_CTRL   0x00c4
#define XLOCKIN_TOP_CTL_ADDR_LOG_MEM_BASE   0x8000
#define XLOCKIN_TOP_CTL_ADDR_LOG_MEM_HIGH   0xffff
#define XLOCKIN_TOP_CTL_WIDTH_LOG_MEM       32
#define XLOCKIN_TOP_CTL_DEPTH_LOG_MEM       8192

